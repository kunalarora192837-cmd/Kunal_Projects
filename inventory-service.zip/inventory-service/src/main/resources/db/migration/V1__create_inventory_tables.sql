CREATE TABLE inventory (
    product_id BIGINT PRIMARY KEY,
    on_hand_quantity BIGINT NOT NULL CHECK (on_hand_quantity >= 0),
    reserved_quantity BIGINT NOT NULL DEFAULT 0 CHECK (reserved_quantity >= 0),
    CONSTRAINT chk_reserved_not_above_on_hand CHECK (reserved_quantity <= on_hand_quantity),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE inventory_reservation (
    id UUID PRIMARY KEY,
    product_id BIGINT NOT NULL REFERENCES inventory(product_id),
    quantity BIGINT NOT NULL CHECK (quantity > 0),
    idempotency_key VARCHAR(120) NOT NULL UNIQUE,
    status VARCHAR(20) NOT NULL CHECK (status IN ('PENDING','RESERVED','CONFIRMED','RELEASED','EXPIRED','FULFILLED')),
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_reservation_expiry ON inventory_reservation(status, expires_at);
CREATE INDEX idx_reservation_product ON inventory_reservation(product_id);
