package com.example.inventory.service;

import com.example.inventory.domain.ReservationStatus;
import com.example.inventory.repository.ReservationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Instant;

@Component
public class ReservationExpiryScheduler {
    private static final Logger log = LoggerFactory.getLogger(ReservationExpiryScheduler.class);
    private final ReservationRepository reservationRepository;
    private final InventoryService inventoryService;

    public ReservationExpiryScheduler(ReservationRepository reservationRepository, InventoryService inventoryService) {
        this.reservationRepository = reservationRepository;
        this.inventoryService = inventoryService;
    }

    @Scheduled(fixedDelayString = "${app.expiry-scan-delay-ms:30000}")
    public void expireReservations() {
        var ids = reservationRepository.findExpiredIds(ReservationStatus.RESERVED, Instant.now());
        for (var id : ids) {
            try {
                inventoryService.expireIfDue(id);
            } catch (Exception ex) {
                // A later scan retries. Alert/metric collection should be added in production.
                log.error("Failed to expire reservation {}. It will be retried by a later scan.", id, ex);
            }
        }
    }
}
