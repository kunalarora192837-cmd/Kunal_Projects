package com.example.inventory.repository;

import com.example.inventory.domain.Inventory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface InventoryRepository extends JpaRepository<Inventory, Long> {
    @Modifying
    @Query(value = "UPDATE inventory SET reserved_quantity = reserved_quantity + :quantity, updated_at = now() " +
            "WHERE product_id = :productId AND :quantity > 0 " +
            "AND on_hand_quantity - reserved_quantity >= :quantity", nativeQuery = true)
    int reserveIfAvailable(@Param("productId") Long productId, @Param("quantity") long quantity);

    @Modifying
    @Query(value = "UPDATE inventory SET reserved_quantity = reserved_quantity - :quantity, updated_at = now() " +
            "WHERE product_id = :productId AND reserved_quantity >= :quantity", nativeQuery = true)
    int releaseReserved(@Param("productId") Long productId, @Param("quantity") long quantity);

    @Modifying
    @Query(value = "UPDATE inventory SET reserved_quantity = reserved_quantity - :quantity, " +
            "on_hand_quantity = on_hand_quantity - :quantity, updated_at = now() " +
            "WHERE product_id = :productId AND reserved_quantity >= :quantity AND on_hand_quantity >= :quantity", nativeQuery = true)
    int fulfillReserved(@Param("productId") Long productId, @Param("quantity") long quantity);
}
