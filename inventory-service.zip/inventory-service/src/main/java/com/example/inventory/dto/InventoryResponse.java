package com.example.inventory.dto;

public record InventoryResponse(Long productId, long onHandQuantity,
                                long reservedQuantity, long availableQuantity) {}
