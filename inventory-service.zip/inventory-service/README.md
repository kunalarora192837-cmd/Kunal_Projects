# Inventory Reservation Service

A Java 17 / Spring Boot / PostgreSQL module demonstrating race-safe inventory reservation for an e-commerce application.

## What it implements

- Atomic inventory reservation (`UPDATE ... WHERE available >= requested quantity`).
- Database-enforced non-negative and reserved-not-above-on-hand constraints.
- Idempotency key uniqueness with PostgreSQL `INSERT ... ON CONFLICT DO NOTHING`.
- Reservation lifecycle: `RESERVED -> CONFIRMED -> FULFILLED`, or `RESERVED -> RELEASED/EXPIRED`.
- Idempotent release and fulfillment operations.
- Expiration worker that retries failed expirations on later scans.
- REST API, validation, and RFC 9457-style `ProblemDetail` errors.
- Flyway migration and Docker Compose PostgreSQL dependency.

## Run locally

Requirements: Java 17+, Maven 3.9+, Docker Compose.

1. Start PostgreSQL:

   ```bash
   docker compose up -d
   ```

2. Start the app:

   ```bash
   mvn spring-boot:run
   ```

Flyway creates the schema. Defaults are in `src/main/resources/application.yml`; override with `DB_URL`, `DB_USERNAME`, and `DB_PASSWORD` as needed.

## API examples

Create initial inventory (bootstrap/admin operation; protect it with authorization in a real deployment):

```bash
curl -X POST http://localhost:8082/api/v1/inventory \
  -H 'Content-Type: application/json' \
  -d '{"productId":101,"initialQuantity":5}'
```

Check inventory:

```bash
curl http://localhost:8082/api/v1/inventory/101
```

Reserve one unit. The idempotency key must be unique per logical reservation attempt and reused on retries of that same attempt:

```bash
curl -X POST http://localhost:8082/api/v1/reservations \
  -H 'Content-Type: application/json' \
  -H 'Idempotency-Key: checkout-order-9001-line-1-attempt-1' \
  -d '{"productId":101,"quantity":1}'
```

The response includes `reservationId`. Use it for subsequent operations:

```bash
curl -X POST http://localhost:8082/api/v1/reservations/RESERVATION_UUID/confirm
curl -X POST http://localhost:8082/api/v1/reservations/RESERVATION_UUID/fulfill
curl -X POST http://localhost:8082/api/v1/reservations/RESERVATION_UUID/release
```

Replace `RESERVATION_UUID` with the returned UUID. Confirm only after the order/payment workflow has established the required business authorization. Fulfill only when fulfillment is authorized. Release only when the payment/order workflow knows it is safe to do so.

## State semantics

- `RESERVED`: stock is held and counts against availability.
- `CONFIRMED`: order is committed to proceed; stock remains reserved.
- `FULFILLED`: physical stock is consumed; both on-hand and reserved quantities decrease.
- `RELEASED` / `EXPIRED`: the reservation is terminal and reserved quantity is decreased once.
- `PENDING`: transaction-internal state only; the reservation and inventory change are committed together, so normal application operation should not leave committed PENDING rows.

## Important production hardening

This is a focused inventory module, not a full checkout/payment system. Before production use:

1. Add authentication/authorization; the bootstrap inventory endpoint must be admin-only.
2. Add request correlation, metrics, tracing, alerting, and structured audit events.
3. Add a transactional outbox and idempotent event consumers when integrating Order/Payment/Fulfillment services through Kafka.
4. Reconcile uncertain payment outcomes before releasing inventory; a payment timeout does not prove payment failure.
5. Add load/concurrency integration tests against PostgreSQL, including duplicate idempotency-key races, crash recovery, expiry races, and multiple application instances.
6. Add an operational policy for expired/failed reservation rows and idempotency-key retention.
7. Consider pagination/batching and row-claiming (`FOR UPDATE SKIP LOCKED`) if reservation volume makes the expiry scan large.
8. Apply authorization and rate limits to public APIs; validate that the authenticated customer owns the related order/reservation.

The idempotency mechanism is scoped to a single reservation operation. The caller must create a distinct key for each genuinely new attempt and reuse the same key only when retrying that same attempt.
