package com.example.inventory.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record ReserveStockRequest(@NotNull @Min(1) Long productId,
                                  @NotNull @Min(1) Long quantity) {}
