package com.example.inventory.domain;

public enum ReservationStatus {
    PENDING, RESERVED, CONFIRMED, RELEASED, EXPIRED, FULFILLED
}
