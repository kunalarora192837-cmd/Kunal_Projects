package com.example.inventory.repository;

import com.example.inventory.domain.InventoryReservation;
import com.example.inventory.domain.ReservationStatus;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ReservationRepository extends JpaRepository<InventoryReservation, UUID> {
    Optional<InventoryReservation> findByIdempotencyKey(String idempotencyKey);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select r from InventoryReservation r where r.id = :id")
    Optional<InventoryReservation> findByIdForUpdate(@Param("id") UUID id);

    @Modifying
    @Query(value = "INSERT INTO inventory_reservation " +
            "(id, product_id, quantity, idempotency_key, status, expires_at) " +
            "VALUES (:id, :productId, :quantity, :key, 'PENDING', :expiresAt) " +
            "ON CONFLICT (idempotency_key) DO NOTHING", nativeQuery = true)
    int insertPendingIfKeyAbsent(@Param("id") UUID id, @Param("productId") Long productId,
                                 @Param("quantity") long quantity, @Param("key") String key,
                                 @Param("expiresAt") Instant expiresAt);

    @Query("select r.id from InventoryReservation r where r.status = :status and r.expiresAt <= :now order by r.expiresAt")
    List<UUID> findExpiredIds(@Param("status") ReservationStatus status, @Param("now") Instant now);
}
