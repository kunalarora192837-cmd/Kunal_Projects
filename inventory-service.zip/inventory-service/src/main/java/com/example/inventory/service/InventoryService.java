package com.example.inventory.service;

import com.example.inventory.domain.Inventory;
import com.example.inventory.domain.InventoryReservation;
import com.example.inventory.domain.ReservationStatus;
import com.example.inventory.dto.InventoryResponse;
import com.example.inventory.dto.ReservationResponse;
import com.example.inventory.exception.IdempotencyConflictException;
import com.example.inventory.exception.InsufficientStockException;
import com.example.inventory.exception.InvalidReservationStateException;
import com.example.inventory.exception.ResourceNotFoundException;
import com.example.inventory.repository.InventoryRepository;
import com.example.inventory.repository.ReservationRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

@Service
public class InventoryService {
    private final InventoryRepository inventoryRepository;
    private final ReservationRepository reservationRepository;
    private final long reservationTtlMinutes;

    public InventoryService(InventoryRepository inventoryRepository,
                            ReservationRepository reservationRepository,
                            @Value("${app.reservation-ttl-minutes:15}") long reservationTtlMinutes) {
        this.inventoryRepository = inventoryRepository;
        this.reservationRepository = reservationRepository;
        if (reservationTtlMinutes < 1) throw new IllegalArgumentException("Reservation TTL must be at least 1 minute");
        this.reservationTtlMinutes = reservationTtlMinutes;
    }

    @Transactional
    public InventoryResponse createInventory(Long productId, long initialQuantity) {
        if (productId == null || productId <= 0 || initialQuantity < 0) {
            throw new IllegalArgumentException("Invalid productId or initial quantity");
        }
        if (inventoryRepository.existsById(productId)) {
            throw new DataIntegrityViolationException("Inventory already exists for product " + productId);
        }
        Inventory saved = inventoryRepository.save(new Inventory(productId, initialQuantity));
        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public InventoryResponse getInventory(Long productId) {
        Inventory inventory = inventoryRepository.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory not found for product " + productId));
        return toResponse(inventory);
    }

    /**
     * Uses PostgreSQL ON CONFLICT to claim an idempotency key before reserving stock.
     * The PENDING row and stock update are in one transaction, so PENDING is never committed
     * by this method. Concurrent calls using the same key serialize on the unique constraint.
     */
    @Transactional
    public ReservationResponse reserve(Long productId, long quantity, String idempotencyKey) {
        if (productId == null || productId <= 0) throw new IllegalArgumentException("productId must be positive");
        if (quantity <= 0) throw new IllegalArgumentException("quantity must be positive");
        if (idempotencyKey == null || idempotencyKey.isBlank() || idempotencyKey.length() > 120) {
            throw new IllegalArgumentException("Idempotency-Key header is required and must be at most 120 characters");
        }

        UUID candidateId = UUID.randomUUID();
        Instant expiresAt = Instant.now().plus(reservationTtlMinutes, ChronoUnit.MINUTES);
        int inserted = reservationRepository.insertPendingIfKeyAbsent(
                candidateId, productId, quantity, idempotencyKey, expiresAt);

        if (inserted == 0) {
            InventoryReservation existing = reservationRepository.findByIdempotencyKey(idempotencyKey)
                    .orElseThrow(() -> new IllegalStateException("Idempotency conflict; retry the request"));
            if (!existing.matches(productId, quantity)) throw new IdempotencyConflictException();
            return ReservationResponse.from(existing);
        }

        int updated = inventoryRepository.reserveIfAvailable(productId, quantity);
        if (updated != 1) throw new InsufficientStockException(productId);

        InventoryReservation reservation = reservationRepository.findById(candidateId)
                .orElseThrow(() -> new IllegalStateException("Reservation row was not created"));
        reservation.setStatus(ReservationStatus.RESERVED);
        return ReservationResponse.from(reservation);
    }

    @Transactional
    public ReservationResponse confirm(UUID reservationId) {
        InventoryReservation reservation = getForUpdate(reservationId);
        if (reservation.getStatus() == ReservationStatus.CONFIRMED ||
            reservation.getStatus() == ReservationStatus.FULFILLED) {
            return ReservationResponse.from(reservation); // idempotent repeat
        }
        if (reservation.getStatus() != ReservationStatus.RESERVED) {
            throw new InvalidReservationStateException("Only RESERVED reservations can be confirmed");
        }
        if (!reservation.getExpiresAt().isAfter(Instant.now())) {
            releaseLocked(reservation, ReservationStatus.EXPIRED);
            return ReservationResponse.from(reservation);
        }
        reservation.setStatus(ReservationStatus.CONFIRMED);
        return ReservationResponse.from(reservation);
    }

    @Transactional
    public ReservationResponse release(UUID reservationId) {
        InventoryReservation reservation = getForUpdate(reservationId);
        if (reservation.getStatus() == ReservationStatus.RELEASED ||
            reservation.getStatus() == ReservationStatus.EXPIRED) {
            return ReservationResponse.from(reservation); // never release twice
        }
        if (reservation.getStatus() != ReservationStatus.RESERVED) {
            throw new InvalidReservationStateException("Only RESERVED reservations can be released");
        }
        releaseLocked(reservation, ReservationStatus.RELEASED);
        return ReservationResponse.from(reservation);
    }

    @Transactional
    public ReservationResponse fulfill(UUID reservationId) {
        InventoryReservation reservation = getForUpdate(reservationId);
        if (reservation.getStatus() == ReservationStatus.FULFILLED) return ReservationResponse.from(reservation);
        if (reservation.getStatus() != ReservationStatus.CONFIRMED) {
            throw new InvalidReservationStateException("Only CONFIRMED reservations can be fulfilled");
        }
        int updated = inventoryRepository.fulfillReserved(reservation.getProductId(), reservation.getQuantity());
        if (updated != 1) throw new IllegalStateException("Inventory invariant violation while fulfilling reservation");
        reservation.setStatus(ReservationStatus.FULFILLED);
        return ReservationResponse.from(reservation);
    }

    @Transactional
    public void expireIfDue(UUID reservationId) {
        InventoryReservation reservation = reservationRepository.findByIdForUpdate(reservationId).orElse(null);
        if (reservation == null || reservation.getStatus() != ReservationStatus.RESERVED) return;
        if (reservation.getExpiresAt().isAfter(Instant.now())) return;
        releaseLocked(reservation, ReservationStatus.EXPIRED);
    }

    @Transactional(readOnly = true)
    public ReservationResponse getReservation(UUID reservationId) {
        return reservationRepository.findById(reservationId)
                .map(ReservationResponse::from)
                .orElseThrow(() -> new ResourceNotFoundException("Reservation not found: " + reservationId));
    }

    private InventoryReservation getForUpdate(UUID id) {
        return reservationRepository.findByIdForUpdate(id)
                .orElseThrow(() -> new ResourceNotFoundException("Reservation not found: " + id));
    }

    private void releaseLocked(InventoryReservation reservation, ReservationStatus targetStatus) {
        int updated = inventoryRepository.releaseReserved(reservation.getProductId(), reservation.getQuantity());
        if (updated != 1) throw new IllegalStateException("Inventory invariant violation while releasing reservation");
        reservation.setStatus(targetStatus);
    }

    private InventoryResponse toResponse(Inventory inventory) {
        return new InventoryResponse(inventory.getProductId(), inventory.getOnHandQuantity(),
                inventory.getReservedQuantity(), inventory.getAvailableQuantity());
    }
}
