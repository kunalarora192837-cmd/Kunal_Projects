package com.example.inventory.domain;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "inventory")
public class Inventory {
    @Id
    @Column(name = "product_id")
    private Long productId;

    @Column(name = "on_hand_quantity", nullable = false)
    private long onHandQuantity;

    @Column(name = "reserved_quantity", nullable = false)
    private long reservedQuantity;

    @Column(name = "created_at", nullable = false, insertable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false, insertable = false, updatable = false)
    private Instant updatedAt;

    protected Inventory() {}

    public Inventory(Long productId, long initialQuantity) {
        if (productId == null || productId <= 0) throw new IllegalArgumentException("productId must be positive");
        if (initialQuantity < 0) throw new IllegalArgumentException("initialQuantity cannot be negative");
        this.productId = productId;
        this.onHandQuantity = initialQuantity;
        this.reservedQuantity = 0;
    }

    public Long getProductId() { return productId; }
    public long getOnHandQuantity() { return onHandQuantity; }
    public long getReservedQuantity() { return reservedQuantity; }
    public long getAvailableQuantity() { return onHandQuantity - reservedQuantity; }
}
