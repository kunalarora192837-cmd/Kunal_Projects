package com.example.inventory.api;

import com.example.inventory.dto.ReservationResponse;
import com.example.inventory.dto.ReserveStockRequest;
import com.example.inventory.service.InventoryService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/reservations")
public class ReservationController {
    private final InventoryService inventoryService;
    public ReservationController(InventoryService inventoryService) { this.inventoryService = inventoryService; }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ReservationResponse reserve(
            @RequestHeader("Idempotency-Key") String idempotencyKey,
            @Valid @RequestBody ReserveStockRequest request) {
        return inventoryService.reserve(request.productId(), request.quantity(), idempotencyKey);
    }

    @GetMapping("/{reservationId}")
    public ReservationResponse get(@PathVariable UUID reservationId) {
        return inventoryService.getReservation(reservationId);
    }

    /** Called by the order workflow after payment authorization succeeds. */
    @PostMapping("/{reservationId}/confirm")
    public ReservationResponse confirm(@PathVariable UUID reservationId) {
        return inventoryService.confirm(reservationId);
    }

    /** Called by the order workflow when cancellation/payment failure makes release safe. */
    @PostMapping("/{reservationId}/release")
    public ReservationResponse release(@PathVariable UUID reservationId) {
        return inventoryService.release(reservationId);
    }

    /** Called by the fulfillment workflow after shipment/fulfillment is authorized. */
    @PostMapping("/{reservationId}/fulfill")
    public ReservationResponse fulfill(@PathVariable UUID reservationId) {
        return inventoryService.fulfill(reservationId);
    }
}
