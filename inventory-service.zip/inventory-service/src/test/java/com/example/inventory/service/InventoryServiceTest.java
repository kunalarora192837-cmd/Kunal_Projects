package com.example.inventory.service;

import com.example.inventory.domain.InventoryReservation;
import com.example.inventory.domain.ReservationStatus;
import com.example.inventory.dto.ReservationResponse;
import com.example.inventory.exception.IdempotencyConflictException;
import com.example.inventory.exception.InsufficientStockException;
import com.example.inventory.repository.InventoryRepository;
import com.example.inventory.repository.ReservationRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.util.Optional;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class InventoryServiceTest {
    private InventoryRepository inventoryRepository;
    private ReservationRepository reservationRepository;
    private InventoryService service;

    @BeforeEach
    void setUp() {
        inventoryRepository = mock(InventoryRepository.class);
        reservationRepository = mock(ReservationRepository.class);
        service = new InventoryService(inventoryRepository, reservationRepository, 15);
    }

    @Test
    void reserveCreatesReservationWhenStockIsAvailable() {
        when(reservationRepository.insertPendingIfKeyAbsent(any(), eq(101L), eq(2L), eq("key-1"), any())).thenReturn(1);
        when(inventoryRepository.reserveIfAvailable(101L, 2L)).thenReturn(1);
        when(reservationRepository.findById(any(UUID.class))).thenAnswer(invocation ->
                Optional.of(new InventoryReservation(101L, 2L, "key-1", Instant.now().plusSeconds(900))));

        ReservationResponse response = service.reserve(101L, 2L, "key-1");

        assertEquals(101L, response.productId());
        assertEquals(2L, response.quantity());
        assertEquals(ReservationStatus.RESERVED, response.status());
        verify(inventoryRepository).reserveIfAvailable(101L, 2L);
    }

    @Test
    void insufficientStockThrowsAndTransactionRollsBackAtSpringBoundary() {
        when(reservationRepository.insertPendingIfKeyAbsent(any(), eq(101L), eq(2L), eq("key-2"), any())).thenReturn(1);
        when(inventoryRepository.reserveIfAvailable(101L, 2L)).thenReturn(0);
        assertThrows(InsufficientStockException.class, () -> service.reserve(101L, 2L, "key-2"));
    }

    @Test
    void reusedIdempotencyKeyWithDifferentRequestIsRejected() {
        when(reservationRepository.insertPendingIfKeyAbsent(any(), eq(101L), eq(2L), eq("key-3"), any())).thenReturn(0);
        InventoryReservation existing = new InventoryReservation(101L, 1L, "key-3", Instant.now().plusSeconds(900));
        when(reservationRepository.findByIdempotencyKey("key-3")).thenReturn(Optional.of(existing));
        assertThrows(IdempotencyConflictException.class, () -> service.reserve(101L, 2L, "key-3"));
        verifyNoInteractions(inventoryRepository);
    }
}
