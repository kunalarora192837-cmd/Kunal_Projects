package com.example.inventory.domain;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "inventory_reservation")
public class InventoryReservation {
    @Id
    private UUID id;

    @Column(name = "product_id", nullable = false)
    private Long productId;

    @Column(nullable = false)
    private long quantity;

    @Column(name = "idempotency_key", nullable = false, unique = true, length = 120)
    private String idempotencyKey;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ReservationStatus status;

    @Column(name = "expires_at", nullable = false)
    private Instant expiresAt;

    @Column(name = "created_at", nullable = false, insertable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false, insertable = false)
    private Instant updatedAt;

    protected InventoryReservation() {}

    public InventoryReservation(Long productId, long quantity, String idempotencyKey, Instant expiresAt) {
        this.id = UUID.randomUUID();
        this.productId = productId;
        this.quantity = quantity;
        this.idempotencyKey = idempotencyKey;
        this.expiresAt = expiresAt;
        this.status = ReservationStatus.PENDING;
    }

    public void setStatus(ReservationStatus status) { this.status = status; }

    @PreUpdate
    void touchUpdatedAt() { this.updatedAt = Instant.now(); }
    public UUID getId() { return id; }
    public Long getProductId() { return productId; }
    public long getQuantity() { return quantity; }
    public String getIdempotencyKey() { return idempotencyKey; }
    public ReservationStatus getStatus() { return status; }
    public Instant getExpiresAt() { return expiresAt; }
    public boolean matches(Long requestedProductId, long requestedQuantity) {
        return productId.equals(requestedProductId) && quantity == requestedQuantity;
    }
}
