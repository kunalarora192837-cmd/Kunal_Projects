package com.example.inventory.dto;

import com.example.inventory.domain.InventoryReservation;
import com.example.inventory.domain.ReservationStatus;
import java.time.Instant;
import java.util.UUID;

public record ReservationResponse(UUID reservationId, Long productId, long quantity,
                                  ReservationStatus status, Instant expiresAt) {
    public static ReservationResponse from(InventoryReservation r) {
        return new ReservationResponse(r.getId(), r.getProductId(), r.getQuantity(), r.getStatus(), r.getExpiresAt());
    }
}
